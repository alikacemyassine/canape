---
name: LE CANAPÉ Official
colors:
  surface: '#fff8f3'
  surface-dim: '#dfd9d4'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f9f2ed'
  surface-container: '#f3ede8'
  surface-container-high: '#eee7e2'
  surface-container-highest: '#e8e1dc'
  on-surface: '#1d1b18'
  on-surface-variant: '#564337'
  inverse-surface: '#353027'
  inverse-on-surface: '#FAEFE1'
  outline: '#897265'
  outline-variant: '#DDC1B1'
  surface-tint: '#964900'
  primary: '#723600'
  on-primary: '#FFFFFF'
  primary-container: '#F08128'
  on-primary-container: '#ffcfb1'
  inverse-primary: '#ffb787'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfdf'
  on-secondary-container: '#636262'
  tertiary: '#5a4311'
  on-tertiary: '#ffffff'
  tertiary-container: '#745a27'
  on-tertiary-container: '#f6d395'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcc7'
  primary-fixed-dim: '#ffb787'
  on-primary-fixed: '#311300'
  on-primary-fixed-variant: '#723600'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c6'
  on-secondary-fixed: '#1c1b1c'
  on-secondary-fixed-variant: '#474647'
  tertiary-fixed: '#ffdea4'
  tertiary-fixed-dim: '#e4c285'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5a4312'
  background: '#fff8f3'
  on-background: '#201B13'
  surface-variant: '#ECE1D3'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 80px
    fontWeight: '600'
    lineHeight: 96px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '500'
    lineHeight: 56px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.15em
spacing:
  stack-sm: 8px
  stack-md: 24px
  stack-lg: 48px
  gutter: 32px
  margin-mobile: 24px
  margin-desktop: 80px
  section-gap: 160px
---

## Brand & Style

The design system embodies a "Quiet Luxury" philosophy, prioritizing high-end craftsmanship and sophisticated minimalism. It is tailored for a discerning audience that values heritage, quality, and timeless elegance. The aesthetic is professional yet warm, evocative of a luxury atelier or a high-end architectural studio.

The visual style is **Corporate / Modern** with a **Minimalist** soul. It utilizes generous whitespace, refined serif typography, and a "layered" architecture. While the interface appears structured and grounded, it is elevated by cinematic motion and subtle depth—most notably through specialized glassmorphism effects and magnetic interactions that provide a tactile, responsive feel to the digital experience.

## Colors

The palette is rooted in earth tones and warm neutrals to reinforce a sense of organic luxury. 

- **Primary**: A rich, deep ochre used for high-impact branding and primary calls to action.
- **Tertiary (Brand Gold)**: Reserved for decorative accents, featured labels, and active states to provide a subtle metallic shimmer.
- **Neutral/Surface**: A creamy off-white (`#FFF8F3`) serves as the canvas, preventing the starkness of pure white while maintaining a clean appearance.
- **Inverse Surface**: Used for deep-toned hero sections and headers to create a dramatic contrast against the light body sections.

Use `primary-container` specifically for selection states or active feedback loops. Ensure all text on `inverse-surface` utilizes `inverse-on-surface` for optimal legibility.

## Typography

This design system employs a classic high-contrast pairing:
1. **Playfair Display**: Used for all editorial headings. Its serif strokes provide an authoritative and literary tone. `display-lg` should be reserved for hero sections and major landing moments.
2. **Inter**: A utilitarian sans-serif used for body copy and labels. It ensures maximum readability across all screen sizes.

**Responsive Strategy**:
- On mobile devices, `display-lg` transitions to the sizing of `headline-lg`.
- `headline-lg` reduces to `headline-lg-mobile` (32px) to maintain a balanced typographic scale on smaller viewports.
- Always use `label-caps` for metadata or navigation items to create a distinct visual hierarchy against body text.

## Layout & Spacing

The layout philosophy follows a **Fixed Grid** approach for content containers to ensure a premium, centered focus on large displays.

- **Grid & Gutters**: Use a 32px (`gutter`) gap for product grids and content blocks.
- **Margins**: A generous 80px horizontal margin on desktop creates an airy, exclusive feel, while 24px is used on mobile to maximize screen real estate without sacrificing breathing room.
- **Vertical Rhythm**: Use `section-gap` (160px) to separate major content areas, reinforcing the minimalist "less is more" approach.
- **Internal Spacing**: `stack-md` (24px) is the standard spacing unit for grouping related elements like text blocks or footer links.

## Elevation & Depth

Visual hierarchy is primarily conveyed through **Tonal Layers** and **Glassmorphism** rather than traditional drop shadows.

- **Glass Nav**: The navigation bar utilizes a sophisticated backdrop blur of 16px with a 85% opacity fill of the surface color (`#FFF8F3D9`). This creates a sense of depth as content slides underneath during scroll.
- **Hero Overlays**: Image-heavy sections use semi-transparent black overlays (ranging from 40% to 60%) to ensure text legibility while maintaining the background's visual impact.
- **Tonal Tiers**: Use `surface-variant` and `surface-container-low` to distinguish between different information containers (e.g., product filters vs. card backgrounds) without using borders.
- **Shadows**: Use `shadow-2xl` sparingly, only for high-priority floating elements like the main header, to provide a significant vertical lift.

## Shapes

While the core philosophy favors **sharp edges** for a modern and architectural feel, specific containers utilize purposeful curves to soften the experience:

- **Global Elements**: Buttons, inputs, and primary containers use 0px roundedness (Sharp) to maintain an institutional and high-end look.
- **Exceptions**:
    - **Product Containers**: Use 12px (`rounded-xl`) to frame product photography gently.
    - **Hero Feature**: The bottom of the primary hero header features a dramatic 40px (`2.5rem`) organic curve to create a unique brand signature.

## Components

- **Navigation**: The `glass-nav` is sticky. Links should implement a "magnetic" interaction where the text moves slightly toward the cursor on hover.
- **Buttons**: Square, sharp corners. Primary buttons use the `#964900` background with white text. Secondary buttons use a 1px `outline` with no background.
- **Filter Tags**: Use `surface-container-low` with a 2px bottom border (`border-b-2`) in the primary color when in an active state.
- **Cards**: Product cards use 12px rounded corners for the image container only. Text beneath is left-aligned with sharp alignment to the grid.
- **Accordions**: High-interaction flex-grow accordions are used for feature sections. These should expand smoothly using a cinematic easing curve.
- **Input Fields**: Minimalist 1px bottom border using `outline-variant`. Focus states should transition the border color to `primary`.
- **Icons**: Use Material Symbols Outlined exclusively, with a weight and fill setting that ensures they appear delicate and lightweight.